import React from 'react'

export default function Login(props) {
    console.log('props',props);
    return (
        <div>
            Login
        </div>
    )
}
