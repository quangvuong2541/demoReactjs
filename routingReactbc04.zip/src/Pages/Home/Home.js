import React from 'react'

export default function Home(props) {

    console.log('props',props)
    

    return (
        <div>
            Home
        </div>
    )
}
