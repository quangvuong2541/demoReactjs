import {applyMiddleware, combineReducers, createStore} from 'redux';
import { PhimReducer } from './reducers/PhimReducer';
import reduxThunk from 'redux-thunk'

const rootReducer = combineReducers({
    //Chứa các state của ứng dụng
    PhimReducer
})

export const store = createStore(rootReducer,applyMiddleware(reduxThunk) );

